#include <RcppArmadilloExtensions/sample.h>
#include <Rcpp.h>
#include <RcppParallel.h>

// [[Rcpp::depends(RcppParallel)]]
// [[Rcpp::plugins(cpp11)]]
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp ;
using namespace RcppParallel;


//########################################################################################################################################
// function to generate normal random variable
// [[Rcpp::export]]
double rnorm(double a, double b) { // a: mean, b: s.d.
	double c=a+b*sum(rnorm(1));
    return c;
}

//########################################################################################################################################
// function to compute the nb distribution
// [[Rcpp::export]]
double dnb(int n, int m, double c) { 
	
double d=R::dpois(n,(m+1)/c,1);
return d;
}

//########################################################################################################################################
// function to for inverse of logit
// [[Rcpp::export]]
double logit(double a) { 
    return log(a/(1-a));
}

//########################################################################################################################################
// function to for inverse of logit
// [[Rcpp::export]]
double invlogit(double a) { 
    return exp(a)/(1+exp(a));
}


//########################################################################################################################################
// function to generate binomial random number
// [[Rcpp::export]]
int gen_binom(double p){
double cut=(double)rand()/(RAND_MAX);
int out=0;
if (cut<p){
out=1;
}

return out;
}


//########################################################################################################################################
// function to general multiviariable normal given sigma
// [[Rcpp::export]]
NumericVector rmnorm(arma::mat sigma) {
int ncols=sigma.n_cols;
arma::rowvec c=arma::randn(1,ncols);
arma::rowvec a=c*arma::chol(sigma);   
NumericVector b=NumericVector(a.begin(),a.end());   
return b;
}

//########################################################################################################################################
//########################################################################################################################################
// the main body of the parallel for doing simulation
struct SimData:public Worker{
// source vector
int stoptime;
RMatrix<int> data1;
RVector<double> para;
RVector<double> para2;
RVector<double> SI_vector;
RVector<double> inc_vector;
RVector<double> missing;
int sep1;
int sep2;
RMatrix<double> record;
// destination vector
// initialize with source and destination
SimData(int stoptime,
IntegerMatrix data1,
NumericVector para,
NumericVector para2,
NumericVector SI_vector,
NumericVector inc_vector,
NumericVector missing,
int sep1,
int sep2,
NumericMatrix record) 
:stoptime(stoptime),data1(data1),para(para),para2(para2),SI_vector(SI_vector),inc_vector(inc_vector),missing(missing),sep1(sep1),sep2(sep2),record(record){}
void operator()(std::size_t begin, std::size_t end) {
// section to write the parallel version
// functor (pass input and output matrixes)
for (unsigned int b1=begin;b1<end;++b1){

int b2;
int b3;
int b4;
// generate the age
data1(b1,0)=b1+1;
data1(b1,1)=rand()%5+2;
//if (gen_binom(0.00)){
//data1(b1,1)=rand()%80+20;	
//}
data1(b1,2)=3;
for (b2=data1(b1,1)-1;b2>=0;--b2){
// input age
data1(b1,sep1+b2*sep2+4)=gen_binom(para2[1]);
// remove those information 
data1(b1,sep1+b2*sep2)=0;
data1(b1,sep1+b2*sep2+1)=-1;
data1(b1,sep1+b2*sep2+2)=-1;
data1(b1,sep1+b2*sep2+3)=0;
// infection status, WLOG assume the first one is primary cases
if (b2==0){
data1(b1,sep1+b2*sep2)=1;
// infection time, assumed to be 2, so start follow-up at three
data1(b1,sep1+b2*sep2+1)=2;
// symptom time
double simvalue=R::runif(0,1);
for (b4=inc_vector.length()-1;b4>=0;--b4){
simvalue-=inc_vector[b4];
if (simvalue<0){
data1(b1,sep1+b2*sep2+2)=2+b4+1;
// break out from the loop 
break;
}
}
// symptomatic or not
data1(b1,sep1+b2*sep2+3)=gen_binom(para[6+1*(data1(b1,sep1+b2*sep2+4)==1)]);
}
}

// time-invariant susceptibility
double sus[data1(b1,1)];
for (b2=data1(b1,1)-1;b2>=0;--b2){
sus[b2]=para[4]*(data1(b1,sep1+b2*sep2+4)==1);
}

//int stop=-1;
// simulate infection
// time
//for (b3=data1(b1,2);b3<stoptime;++b3){
int stop=data1(b1,sep1+0*sep2+2)+21;
int beingdetected=data1(b1,sep1+0*sep2+3);
b3=data1(b1,2);
do{
// for member	
for (b2=data1(b1,1)-1;b2>=0;--b2){	
// uninfected
if (data1(b1,sep1+b2*sep2)==0){
// community escape probability
double comm=1.0-invlogit(logit(para[0])+sus[b2]);
// hh escape probability
double hh=1;
for (b4=data1(b1,1)-1;b4>=0;--b4){
// not the same ppl
if (b4!=b2){
// infection
if ((data1(b1,sep1+b4*sep2)==1)&&(b3>data1(b1,sep1+b4*sep2+1))){
// time difference between current day and the symptom onset day	
int timed=b3-data1(b1,sep1+b4*sep2+2);
if (timed+5>0&timed+5<SI_vector.length()){
double templogprob=logit(para[1])+sus[b2];
// children relative infectivity
templogprob+=para[5]*(data1(b1,sep1+b4*sep2+4)==1);
// asym vs sym
templogprob+=para[2]*(data1(b1,sep1+b4*sep2+3)==0);
// pre-sym vs after sym
templogprob+=para[3]*(timed<0);
hh*=1.0-invlogit(templogprob)*SI_vector[timed+5];
}
}
}
}
/*
if (b1==0){
record(b2,b3-1)=1.0-comm*hh;
record(b2,b3)=comm;
record(b2,b3+1)=hh;
record(b2,b3+2)=para[0];
record(b2,b3+3)=logit(para[0]);
record(b2,b3+4)=sus[b2];
record(b2,b3+5)=logit(para[0])+sus[b2];
record(b2,b3+6)=invlogit(logit(para[0])+sus[b2]);
}
*/
// simulate infection
if (gen_binom(1.0-comm*hh)){
data1(b1,sep1+b2*sep2)=1;
// infection time
data1(b1,sep1+b2*sep2+1)=b3;
// symptom time
double simvalue=R::runif(0,1);
for (b4=inc_vector.length()-1;b4>=0;--b4){
simvalue-=inc_vector[b4];
if (simvalue<0){
data1(b1,sep1+b2*sep2+2)=b3+b4+1;
// break out from the loop 
break;
}
}
// symptomatic or not
data1(b1,sep1+b2*sep2+3)=gen_binom(para[6+1*(data1(b1,sep1+b2*sep2+4)==1)]);
if (data1(b1,sep1+b2*sep2+3)==1){
beingdetected=1;	
}
// change stoptime
stop=data1(b1,sep1+b2*sep2+2)+16;
}

}
}
++b3;
}
while (b3<stop);

// input the stop followup time
data1(b1,3)=stop;
// input being detected or not
data1(b1,4)=beingdetected;


}
}
};


//########################################################################################################################################
// function for simulation
// [[Rcpp::export]]
List sim_data(int nhousehold,
int stoptime,
NumericVector para, 
NumericVector para2,
NumericVector SI_vector,	
NumericVector inc_vector,
NumericVector missing,
int sep1,
int sep2){ 

int b0;
int b1;
int b2;
int b3;
int b4;
double cut=0;

// assume 2-13 hh member
// clone the input data for simulation
IntegerMatrix data1(nhousehold,10*5+5);
NumericMatrix record(15,150);

SimData simdata1(stoptime,data1,para,para2,SI_vector,inc_vector,missing,sep1,sep2,record);

// call parallelFor to do the work
parallelFor(0,data1.nrow(),simdata1);

return List::create(_[""]=data1,
_[""]=record);
} 




//########################################################################################################################################
// function for simulation
// [[Rcpp::export]]
List sim_data2(int nhousehold,
int stoptime,
NumericVector para, 
NumericVector para2,
NumericVector SI_vector,	
NumericVector inc_vector,
NumericVector missing,
int sep1,
int sep2){ 

int b0;
int b1;
int b2;
int b3;
int b4;
double cut=0;

// assume 2-13 hh member
// clone the input data for simulation
IntegerMatrix data1(nhousehold,10*5+5);
NumericMatrix record(15,150);

for (b1=data1.nrow()-1;b1>=0;--b1){
// generate the age
data1(b1,0)=b1+1;
data1(b1,1)=rand()%5+2;
//if (R::rbinom(1,0.00)){
//data1(b1,1)=rand()%80+20;	
//}
data1(b1,2)=3;
for (b2=data1(b1,1)-1;b2>=0;--b2){
// input age
data1(b1,sep1+b2*sep2+4)=gen_binom(para2[1]);
// remove those information 
data1(b1,sep1+b2*sep2)=0;
data1(b1,sep1+b2*sep2+1)=-1;
data1(b1,sep1+b2*sep2+2)=-1;
data1(b1,sep1+b2*sep2+3)=0;
// infection status, WLOG assume the first one is primary cases
if (b2==0){
data1(b1,sep1+b2*sep2)=1;
// infection time, assumed to be 2, so start follow-up at three
data1(b1,sep1+b2*sep2+1)=2;
// symptom time
double simvalue=R::runif(0,1);
for (b4=inc_vector.length()-1;b4>=0;--b4){
simvalue-=inc_vector[b4];
if (simvalue<0){
data1(b1,sep1+b2*sep2+2)=2+b4+1;
// break out from the loop 
break;
}
}
// symptomatic or not
data1(b1,sep1+b2*sep2+3)=gen_binom(para[6+1*(data1(b1,sep1+b2*sep2+4)==1)]);
}
}

// time-invariant susceptibility
double sus[data1(b1,1)];
for (b2=data1(b1,1)-1;b2>=0;--b2){
sus[b2]=para[4]*(data1(b1,sep1+b2*sep2+4)==1);
}

//int stop=-1;
// simulate infection
// time
//for (b3=data1(b1,2);b3<stoptime;++b3){
int stop=data1(b1,sep1+0*sep2+2)+21;
int beingdetected=data1(b1,sep1+0*sep2+3);
b3=data1(b1,2);
do{
// for member	
for (b2=data1(b1,1)-1;b2>=0;--b2){	
// uninfected
if (data1(b1,sep1+b2*sep2)==0){
// community escape probability
double comm=1.0-invlogit(logit(para[0])+sus[b2]);
// hh escape probability
double hh=1;
for (b4=data1(b1,1)-1;b4>=0;--b4){
// not the same ppl
if (b4!=b2){
// infection
if ((data1(b1,sep1+b4*sep2)==1)&&(b3>data1(b1,sep1+b4*sep2+1))){
// time difference between current day and the symptom onset day	
int timed=b3-data1(b1,sep1+b4*sep2+2);
if (timed+5>0&timed+5<SI_vector.length()){
double templogprob=logit(para[1])+sus[b2];
// children relative infectivity
templogprob+=para[5]*(data1(b1,sep1+b4*sep2+4)==1);
// asym vs sym
templogprob+=para[2]*(data1(b1,sep1+b4*sep2+3)==0);
// pre-sym vs after sym
templogprob+=para[3]*(timed<0);
hh*=1.0-invlogit(templogprob)*SI_vector[timed+5];
}
}
}
}
/*
if (b1==0){
record(b2,b3-1)=1.0-comm*hh;
record(b2,b3)=comm;
record(b2,b3+1)=hh;
record(b2,b3+2)=para[0];
record(b2,b3+3)=logit(para[0]);
record(b2,b3+4)=sus[b2];
record(b2,b3+5)=logit(para[0])+sus[b2];
record(b2,b3+6)=invlogit(logit(para[0])+sus[b2]);
}
*/
// simulate infection
if (gen_binom(1.0-comm*hh)){
data1(b1,sep1+b2*sep2)=1;
// infection time
data1(b1,sep1+b2*sep2+1)=b3;
// symptom time
double simvalue=R::runif(0,1);
for (b4=inc_vector.length()-1;b4>=0;--b4){
simvalue-=inc_vector[b4];
if (simvalue<0){
data1(b1,sep1+b2*sep2+2)=b3+b4+1;
// break out from the loop 
break;
}
}
// symptomatic or not
data1(b1,sep1+b2*sep2+3)=gen_binom(para[6+1*(data1(b1,sep1+b2*sep2+4)==1)]);
if (data1(b1,sep1+b2*sep2+3)==1){
beingdetected=1;	
}
// change stoptime
stop=data1(b1,sep1+b2*sep2+2)+16;
}

}
}
++b3;
}
while (b3<stop);

// input the stop followup time
data1(b1,3)=stop;
// input being detected or not
data1(b1,4)=beingdetected;


}

return List::create(_[""]=data1,
_[""]=record);
} 



// change to conditiona likeihood
//########################################################################################################################################
//########################################################################################################################################
// the main body of the parallel for Digraphlikelihood
struct LogLik:public Worker{
// source vector
RMatrix<double> out;
RMatrix<int> data1;
RVector<double> para;
RVector<double> para2;
RVector<double> SI_vector;
RVector<double> inc_vector;
int sep1;
int sep2;
// destination vector
// initialize with source and destination
LogLik(NumericMatrix out,
IntegerMatrix data1,
NumericVector para,
NumericVector para2,
NumericVector SI_vector,
NumericVector inc_vector,
int sep1,
int sep2) 
:out(out),data1(data1),para(para),para2(para2),SI_vector(SI_vector),inc_vector(inc_vector),sep1(sep1),sep2(sep2){}
void operator()(std::size_t begin, std::size_t end) {


// section to write the parallel version
// functor (pass input and output matrixes)
for (unsigned int b1=begin;b1<end;++b1){
	
int b2;
int b3;
int b4;

// time-invariant susceptibility
double sus[data1(b1,1)];
for (b2=data1(b1,1)-1;b2>=0;--b2){
sus[b2]=para[4]*(data1(b1,sep1+b2*sep2+4)==1);
}

// get the origin and the primary of the household
int primary=-1;
int origin=999;
for (b2=data1(b1,1)-1;b2>=0;--b2){
// infection
if (data1(b1,sep1+b2*sep2)==1){
// the minimum infection time
if (data1(b1,sep1+b2*sep2+1)<origin){
origin=data1(b1,sep1+b2*sep2+1);
primary=b2;
}
}
}

for (b2=data1(b1,1)-1;b2>=0;--b2){
if (b2!=primary){	
// compute from infection time to the origin if infected, or end of followup in not infected
int endpt=data1(b1,3);
if (data1(b1,sep1+b2*sep2)==1){
endpt=data1(b1,sep1+b2*sep2+1);	
}
for (b3=endpt;b3>origin;--b3){
// community escape probability
double comm=1.0-invlogit(logit(para[0])+sus[b2]);
// hh escape probability
double hh=1;
for (b4=data1(b1,1)-1;b4>=0;--b4){
// not the same ppl
if (b4!=b2){
// infection
if ((data1(b1,sep1+b4*sep2)==1)&&(b3>data1(b1,sep1+b4*sep2+1))){
// time difference between current day and the symptom onset day	
int timed=b3-data1(b1,sep1+b4*sep2+2);
if (timed+5>0&timed+5<SI_vector.length()){
double templogprob=logit(para[1])+sus[b2];
// children relative infectivity
templogprob+=para[5]*(data1(b1,sep1+b4*sep2+4)==1);
// asym vs sym
templogprob+=para[2]*(data1(b1,sep1+b4*sep2+3)==0);
// pre-sym vs after sym
templogprob+=para[3]*(timed<0);
hh*=1.0-invlogit(templogprob)*SI_vector[timed+5];
}
}
}
}
if (b3!=data1(b1,sep1+b2*sep2+1)){
out(b1,b2)+=log(comm*hh);
}
else{
out(b1,b2)+=log(1-comm*hh);	
}
}
}
}


for (b2=data1(b1,1)-1;b2>=0;--b2){
if (b2!=primary){	
// if infection
if (data1(b1,sep1+b2*sep2)==1){
// incubation period likelihood
out(b1,b2)+=log(inc_vector[data1(b1,sep1+b2*sep2+2)-data1(b1,sep1+b2*sep2+1)-1]);	
// symptom status
if (data1(b1,sep1+b2*sep2+3)==1){
out(b1,b2)+=log(para[6+1*(data1(b1,sep1+b2*sep2+4)==1)]);
}
else{
out(b1,b2)+=log(1-para[6+1*(data1(b1,sep1+b2*sep2+4)==1)]);	
}
}	
// age likelihood
out(b1,b2)+=log(para2[data1(b1,sep1+b2*sep2+4)]);
}
}

// conditional on at least one symptomatic cases
double all_asym=1;
for (b2=data1(b1,1)-1;b2>=0;--b2){
if (data1(b1,sep1+b2*sep2)==1){
all_asym*=1-para[6+1*(data1(b1,sep1+b2*sep2+4)==1)];
}
}
out(b1,0)+=log(1-all_asym);

}
}
};

//########################################################################################################################################
//function to compute likelihood for infection and symptom
// [[Rcpp::export]]
NumericMatrix loglik(IntegerMatrix data1,
NumericVector para,
NumericVector para2,
NumericVector SI_vector,
NumericVector inc_vector,
int sep1,
int sep2){

// record the likelihood value
NumericMatrix out(data1.nrow(),15); 

// create a vector to compute
LogLik loglik(out,data1,para,para2,SI_vector,inc_vector,sep1,sep2);
// call parallelFor to do the work
parallelFor(0,data1.nrow(),loglik);

return out;
}



//########################################################################################################################################
//function to compute the prior likelihood 
// [[Rcpp::export]]
double prior_loglik(NumericVector para){
// check if the para are within their possible range
NumericVector out(para.length());
int b1;
for (b1=1;b1>=0;--b1){
out(b1)=R::dunif(para(b1),0.000000000000000001,0.99,1);
}
for (b1=5;b1>=2;--b1){
out(b1)=R::dunif(para(b1),-10.0,10.0,1);
}
for (b1=7;b1>=6;--b1){
out(b1)=R::dunif(para(b1),0.000000000000000001,0.99,1);
}
double output=sum(out);
// if the prior is outside the parameter space
if (output< -9999999){
output=-9999999;
}
return output;
}



//##############################################################################################################################################
//##############################################################################################################################################
// function for mcmc
// [[Rcpp::export]]
List mcmc(IntegerMatrix data1, 
NumericVector int_para, 
NumericVector int_para2,
NumericVector SI_vector,	
NumericVector inc_vector,
int mcmc_n,             
NumericVector move,    
NumericVector sigma,
int sep1,
int sep2){            

// create the vector for use
int b0;
int b1;
int b2;
int b3;
int b4;
int moveindex;

// need to set number of parameter here
NumericMatrix p_para(mcmc_n,int_para.length());
NumericMatrix p_para_r(mcmc_n,sum(move));
p_para(0,_)=int_para;
moveindex=sum(move)-1;
for (b1=int_para.length()-1;b1>=0;--b1){
if (move(b1)){
p_para_r(0,moveindex)=p_para(0,b1);
--moveindex;
}	
}

// for the second parameter vectors
IntegerMatrix baselinecount(1,int_para2.length());
// count the real count here because those would not change
for (b1=data1.nrow()-1;b1>=0;--b1){
for (b2=data1(b1,1)-1;b2>=0;--b2){
++baselinecount(0,data1(b1,sep1+b2*sep2+4));	
}
}


NumericMatrix p_para2(mcmc_n,int_para2.length());
p_para2(0,_)=int_para2;


// create augmented data
IntegerMatrix data11(clone(data1));

/*
for (b1=data11.nrow()-1;b1>=0;--b1){
// impute the infection time	
if ((data1(b1,14)==-1)&&(data1(b1,10)==1)){	
data11(b1,14)=data11(b1,13);	
}
// imput sympotm onset
if ((data1(b1,11)==-1)&&(data1(b1,10)==1)){	
data11(b1,11)=data11(b1,14)+1;	
}
// impute age
if (data1(b1,9)==-1){
data11(b1,9)=0;	
}
// impute sex
if (data1(b1,8)==-1){
data11(b1,8)=0;
}
// impute inf1 and inf2
if (data1(b1,19)==-1){
data11(b1,19)=1;	
}
}
*/

// matrix to record LL
NumericMatrix LL1(mcmc_n,3);

//####################################################################################################################################
// compute likelihood

NumericMatrix loglik1=loglik(data11,p_para(0,_),p_para2(0,_),SI_vector,inc_vector,sep1,sep2);
NumericMatrix loglik1pro;

LL1(0,0)=sum(loglik1);

NumericVector temploglik(1);
NumericVector newloglik(1);
temploglik(0)=LL1(0,0)+prior_loglik(p_para(0,_));

double loglikeratio;
double accept_pro;
NumericVector pro_para(int_para.length());


//####################################################################################################################################
// main mcmc step
NumericVector acceptrate(int_para.length());
NumericMatrix imputeacceptrate(data11.nrow(),5);
IntegerMatrix infection_record(mcmc_n,sum(data1(_,10)));

//####################################################################################################################################
for (b0=1;b0<mcmc_n;++b0){


// after 500 step, then set the sigma to be the empirical sigma
if ((b0>500)&&(b0%100==0)){
for (b1=int_para.length()-1;b1>=0;--b1){
if (move(b1)){	
NumericVector temp1(b0-1);
for (b2=b0-2;b2>=0;--b2){
temp1(b2)=p_para(b2,b1);	
}
sigma(b1)=sd(temp1);
// tuning
if (acceptrate(b1)<0.1){
sigma(b1)*=0.5;
}	
if ((acceptrate(b1)<0.15)&(acceptrate(b1)>0.1)){
sigma(b1)*=0.8;
}
if ((acceptrate(b1)<0.2)&(acceptrate(b1)>0.15)){
sigma(b1)*=0.95;
}
if ((acceptrate(b1)<0.4)&(acceptrate(b1)>0.3)){
sigma(b1)*=1.05;
}
if ((acceptrate(b1)<0.9)&(acceptrate(b1)>0.4)){
sigma(b1)*=1.2;
}
if (acceptrate(b1)>0.9){
sigma(b1)*=2;
}
}
}

}

// metorpolis-hasing update on parameter

for (b1=0;b1<int_para.length();++b1){
if (move(b1)){
pro_para=p_para(b0-1,_);
for (b2=b1-1;b2>=0;--b2){
pro_para(b2)=p_para(b0,b2);	
}
pro_para(b1)+=rnorm(0.0,sigma(b1));
newloglik(0)=prior_loglik(pro_para);
if (newloglik(0)> -9999999){
loglik1pro=loglik(data11,pro_para,p_para2(b0-1,_),SI_vector,inc_vector,sep1,sep2);
newloglik(0)+=sum(loglik1pro);
loglikeratio=newloglik(0)-temploglik(0);
accept_pro=pow(exp(1),loglikeratio);
}
else{
accept_pro=0;	
}
if(gen_binom(accept_pro)){
loglik1=clone(loglik1pro);		
temploglik(0)=newloglik(0);
p_para(b0,b1)=pro_para(b1);
acceptrate(b1)*=(b0-1);
acceptrate(b1)+=1;
acceptrate(b1)/=b0;
}
else{
p_para(b0,b1)=p_para(b0-1,b1);
acceptrate(b1)*=(b0-1);
acceptrate(b1)/=b0;
}
}
else {
p_para(b0,b1)=p_para(b0-1,b1);
}
}

LL1(b0,0)=temploglik(0)-prior_loglik(p_para(b0,_));

// gibbs sampling for age and sex distribution
// here to update para2
NumericVector tempcount(7);
for (b1=baselinecount.ncol()-1;b1>=0;--b1){
int para3index=1;
if (b1<=1){
para3index=0;	
}
p_para2(b0,b1)=R::rgamma(baselinecount(0,b1)+1.0,1.0);
tempcount(para3index)+=p_para2(b0,b1);
}
for (b1=baselinecount.ncol()-1;b1>=0;--b1){
int para3index=1;
if (b1<=1){
para3index=0;	
}
p_para2(b0,b1)/=tempcount(para3index);
}

// update likelihood after update para2

loglik1=loglik(data11,p_para(b0,_),p_para2(b0,_),SI_vector,inc_vector,sep1,sep2);

LL1(b0,0)=sum(loglik1);
temploglik(0)=LL1(b0,0)+prior_loglik(p_para(b0,_));

/*
// sample missing infomration
// sample age and sex
for (b1=data1.nrow()-1;b1>=0;--b1){
if (data1(b1,1)!=1){
int update=0;
if ((data1(b1,8)==-1)||(data1(b1,9)==-1)||(data1(b1,19)==-1)){
update=gen_binom(0.1);	
}
if (update){
accept_pro=1;
IntegerMatrix data11_pro(clone(data11));	
// sample sex
if (data1(b1,8)==-1){
data11_pro(b1,8)=1-data11(b1,8);
}
// sample age
if (data1(b1,9)==-1){
data11_pro(b1,9)=rand()%8;
}
// sample medppl
if (data1(b1,19)==-1){
data11_pro(b1,19)=1-data11(b1,19);
}
newloglik(0)=prior_loglik(p_para(b0,_));
if (newloglik(0)> -9999999){
loglik1pro=loglik(data11_pro,contactmatrix,p_para(b0,_),p_para2(b0,_),SI_vector,inc_vector);
newloglik(0)+=sum(loglik1pro);
loglikeratio=newloglik(0)-temploglik(0);
accept_pro=pow(exp(1),loglikeratio);
}
if(gen_binom(accept_pro)){
loglik1=clone(loglik1pro);		
temploglik(0)=newloglik(0);
data11=clone(data11_pro);
imputeacceptrate(b1,0)*=(b0-1);
imputeacceptrate(b1,0)+=1;
imputeacceptrate(b1,0)/=b0;
}
else{
imputeacceptrate(b1,0)*=(b0-1);
imputeacceptrate(b1,0)/=b0;
}

}
}
}


// sample infection time
for (b1=data1.nrow()-1;b1>=0;--b1){
if ((data1(b1,14)==-1)&&(data1(b1,10)==1)){	
accept_pro=1;
IntegerMatrix data11_pro(clone(data11));	
// sample infection time
data11_pro(b1,14)=data1(b1,12)+rand()%(data1(b1,13)+1-data1(b1,12));
newloglik(0)=prior_loglik(p_para(b0,_));
if (newloglik(0)> -9999999){
loglik1pro=loglik(data11_pro,contactmatrix,p_para(b0,_),p_para2(b0,_),SI_vector,inc_vector);
newloglik(0)+=sum(loglik1pro);
loglikeratio=newloglik(0)-temploglik(0);
accept_pro=pow(exp(1),loglikeratio);
}
if(gen_binom(accept_pro)){
loglik1=clone(loglik1pro);		
temploglik(0)=newloglik(0);
data11=clone(data11_pro);
imputeacceptrate(b1,2)*=(b0-1);
imputeacceptrate(b1,2)+=1;
imputeacceptrate(b1,2)/=b0;
}
else{
imputeacceptrate(b1,2)*=(b0-1);
imputeacceptrate(b1,2)/=b0;
}
}
}

// sample symptom time
for (b1=data1.nrow()-1;b1>=0;--b1){
if ((data1(b1,11)==-1)&&(data1(b1,10)==1)){	
accept_pro=1;
IntegerMatrix data11_pro(clone(data11));	
// sample infection time
int bound=data1(b1,13)+15;
if (bound>150){
bound=150;
}
data11_pro(b1,11)=data1(b1,12)+rand()%(bound+1-data1(b1,12));
newloglik(0)=prior_loglik(p_para(b0,_));
if (newloglik(0)> -9999999){
loglik1pro=loglik(data11_pro,contactmatrix,p_para(b0,_),p_para2(b0,_),SI_vector,inc_vector);
newloglik(0)+=sum(loglik1pro);
loglikeratio=newloglik(0)-temploglik(0);
accept_pro=pow(exp(1),loglikeratio);
}
if(gen_binom(accept_pro)){
loglik1=clone(loglik1pro);		
temploglik(0)=newloglik(0);
data11=clone(data11_pro);
imputeacceptrate(b1,3)*=(b0-1);
imputeacceptrate(b1,3)+=1;
imputeacceptrate(b1,3)/=b0;
}
else{
imputeacceptrate(b1,3)*=(b0-1);
imputeacceptrate(b1,3)/=b0;
}
}
}




LL1(b0,1)=temploglik(0)-prior_loglik(p_para(b0,_));

int infindex=0;
for (b1=0;b1<=data11.nrow()-1;++b1){
if (data11(b1,10)==1){	
infection_record(b0,infindex)=data11(b1,14);
++infindex;	
}
}
*/

if (b0%100==1){
//if (b0%1==0){
Rcout << "b0: " << b0 << std::endl;
}

}


return List::create(_[""]=p_para,
_[""]=p_para2,
_[""]=LL1,
_[""]=data11,
_[""]=baselinecount,
_[""]=imputeacceptrate,
_[""]=infection_record);
} 

