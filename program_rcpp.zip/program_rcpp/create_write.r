
link <- "/Users/timtsang/Dropbox/2019nCoV/severity_model/program/program_rcpp/"

## set path
setwd(link)

## read the zika.r files

a1 <- readLines(paste(link,"COVID_household.r",sep=""))

## read the run.sh and run2.sh

a2 <- readLines(paste(link,"run.sh",sep=""))
a3 <- readLines(paste(link,"run2.sh",sep=""))

## copy data
#a4 <- readLines(paste(link,"2021_01_11_data.csv",sep=""))
a8 <- readLines(paste(link,"COVID_household.cpp",sep=""))
command <- rep("",100)
runtime <- 1
run2time <- 0
i <- 1
for (b1 in 1:6){
  for (b2 in 1:4){

        name <- paste("model",b1,b2,sep="")
        dir.create(paste("model",b1,b2,sep=""))
        a11 <- a1
        a11[89] <- paste("currentindex1 <- ",b1,sep="")
        a11[90] <- paste("currentindex2 <- ",b2,sep="")
        
     #   a11[51] <- paste("#setwd(\"Z:/COVID_shandong/program_rcpp/2021_01_11/v4/model",b1,b2,"\")",sep="")
        
        writeLines(a11,paste(  name,"/COVID_household.r",sep=""))  
        writeLines(a8,paste(  name,"/COVID_household.cpp",sep=""))  
        writeLines(a2,paste(  name,"/run.sh",sep=""))  
        writeLines(a3,paste(  name,"/run2.sh",sep=""))  
   

        command[i] <- paste("cd",name)
        command[i+1:runtime] <- "sbatch run.sh"
      #  command[i+runtime+1:run2time] <- "sbatch run2.sh"
        command[i+runtime+run2time+1] <- "cd .."
        
        i <- i+runtime+run2time+1+1
        

  }
}




writeLines(command,"command1.txt")  
