#!/bin/bash
#SBATCH --job-name=1st_r
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=8gb
#SBATCH --time=70:00:00
#SBATCH --account=epi
#SBATCH --qos=epi-b
#SBATCH --partition=hpg2-compute

pwd; hostname; date

cat /proc/cpuinfo

module load R

Rscript COVID_household.r

date
