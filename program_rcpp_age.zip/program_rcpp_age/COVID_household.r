
rm(list = ls())

#Sys.setenv("PKG_CXXFLAGS"="-std=c++11")

library(Rcpp)
library(RcppParallel)
library(mvtnorm)
print(defaultNumThreads())
#setThreadOptions(numThreads = 4)
########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}

########
## incubation and infectiousness

incmat <- matrix(NA,4,14)
infmat <- matrix(NA,6,22)

incmat[1,] <- c(0.091,0.16,0.19,0.18,0.15,0.1,0.061,0.032,0.015,0.0061,0.0022,7.2e-4,2.1e-4,5.3e-5)
incmat[2,] <- c(0.058,0.11,0.14,0.16,0.15,0.13,0.1,0.068,0.044,0.026,0.014,0.0072,0.0034,0.0015)
incmat[3,] <- c(0.043,0.079,0.11,0.12,0.13,0.12,0.11,0.088,0.07,0.052,0.037,0.025,0.016,0.0098)
incmat[4,] <- c(0.04,0.065,0.082,0.093,0.098,0.098,0.095,0.088,0.080,0.071,0.061,0.052,0.043,0.035)
incmat <- incmat/rowSums(incmat)
infmat[1,] <- c(rep(1.0,8),0.8,0.6,0.4,0.2,0.1,rep(0,9))
infmat[2,] <- c(rep(1.0,10),0.8,0.8,0.6,0.4,0.2,0.1,rep(0,6))
infmat[3,] <- c(rep(1.0,12),0.8,0.8,0.6,0.6,0.4,0.4,0.3,0.3,0.1,0.1)
infmat[4,] <- c(rep(1.0,6),0.9,0.8,0.7,0.6,0.4,0.2,0.1,rep(0,9))
infmat[5,] <- c(rep(1.0,7),0.9,0.8,0.8,0.7,0.7,0.6,0.4,0.2,0.1,rep(0,6))
infmat[6,] <- c(rep(1.0,8),0.9,0.9,0.8,0.8,0.7,0.7,0.6,0.6,0.4,0.4,0.3,0.3,0.1,0.1)

incvec <- incmat[2,]
infvec <- infmat[3,]

### simulation to determine the power

########
# set link
#setwd("/Users/timtsang/SPH Dropbox/Tim Tsang/Shared hh trial/severity/tim/program/program_rcpp_age")
#setwd("Z:/2019nCoV/severity_model/program/program_rcpp")
##
#data <- read.csv("2021_01_27_data_wide.csv",as.is = T)
## only get those infected and uninfected. i.e. data[,4]==0
#data <- data[data[,4]==0,]


# column 3 used to set the origin for the hosuehold
# inf status, inf time, sym time, sym, children or not

# para 1. from community
# para 2. from household
# para 3. asym vs sym
# para 4. pre-sym vs sym
# para 5. child sus
# para 6. child inf
# para 7. sym prob for adults (or death)
# para 8. sym prob for children (or death)

# age: 0 adults, 1 children
# para2: 1-2 adults/adults

1-exp(sum(log(1-0.00314*infvec)))

1-exp(sum(log(1-0.00641*infvec)))

1-exp(sum(log(1-0.00987*infvec)))

1-exp(sum(log(1-0.0136*infvec)))

vec1 <- c(1/10000,1/1000,1/100,1/50,1/10,1/5)

vec2 <- c(0.00314,0.00641,0.00987,0.0136)

currentindex1 <- 6
currentindex2 <- 4

# set input parameter here
# SAR=5%, death=5%
outcome_rate <- vec1[currentindex1]
SAR <- vec2[currentindex2]

para <- c(0.0000,rep(SAR,1),0,0,0,0,c(outcome_rate/2,outcome_rate))
para2 <- c(0.5,0.5)

#para <- read.csv("para1.csv")[,1]
#para2 <- read.csv("para2.csv")[,1]
# normalized para2
para2[1:2] <- para2[1:2]/sum(para2[1:2])

sourceCpp("COVID_household.cpp")

# number of second cases
# nubmer of secondary case with death
# start to count 10 household to 10000 household?
# the number
record <- matrix(NA,1000,500*2)
record2 <- matrix(NA,1000,500*2)

# binomial CI
recordCI <- matrix(NA,1000,500*2)
recordCI2 <- matrix(NA,1000,500*2)


for (i in 1:1000){
print(i)
# first input is number of household
  sim <- sim_data2(10000,150,para,para2,infvec,incvec,c(0,0),5,5)
testdata <- sim[[1]]


for (j in 1:500){
record[i,2*j-1] <- sum(testdata[1:(20*j),2:8*5+1]==1 & testdata[1:(20*j),2:8*5+5]==0)
record[i,2*j] <- sum(testdata[1:(20*j),2:8*5+1]==1&testdata[1:(20*j),2:8*5+4]==1 & testdata[1:(20*j),2:8*5+5]==0)
record2[i,2*j-1] <- sum(testdata[1:(20*j),2:8*5+1]==1 & testdata[1:(20*j),2:8*5+5]==1)
record2[i,2*j] <- sum(testdata[1:(20*j),2:8*5+1]==1&testdata[1:(20*j),2:8*5+4]==1 & testdata[1:(20*j),2:8*5+5]==1)
if (record[i,2*j-1]>0){
bb <- binom.test(record[i,2*j],record[i,2*j-1])
recordCI[i,c(2*j-1,2*j)] <- bb$conf.int

bb <- binom.test(record2[i,2*j],record2[i,2*j-1])
recordCI2[i,c(2*j-1,2*j)] <- bb$conf.int
}
}
}

mean(record[,1000]/record[,999])

write.csv(recordCI,"power1.csv",row.names = F)
write.csv(recordCI2,"power2.csv",row.names = F)



