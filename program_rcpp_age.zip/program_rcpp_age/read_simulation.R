
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}


setwd("/Users/timtsang/Dropbox/2019nCoV/household/program_rcpp/cond")

rawlist <- list.files(pattern="*.csv")
rawlist1 <- rawlist[grepl("mcmc_summary1",rawlist)]
rawlist2 <- rawlist[grepl("mcmc_summary2",rawlist)]


#int_para <-  read.csv("para1.csv")[,1]
#int_para2 <-  read.csv("para2.csv")[,1]
int_para <- c(0.001,rep(0.1,1),-0.2,0,-0.2,0,c(0.5,0.5))
int_para2 <- c(rep(0.5,2))

nsim <- 50
tt1 <- tt2 <- matrix(NA,nsim,length(int_para))
tt12 <- tt22 <- matrix(NA,nsim,length(int_para2))

for (i in 1:nsim){
  temp <- read.csv(rawlist1[i])  
  tt1[i,] <- temp[,1]
  tt2[i,] <- 1*(temp[,2] <= int_para & temp[,3] >= int_para)
  
  temp <- read.csv(rawlist2[i])  
  tt12[i,] <- temp[,1]
  tt22[i,] <- 1*(temp[,2] <= int_para2 & temp[,3] >= int_para2)
}

summary(tt1)
summary(tt2)

summary(tt12)
summary(tt22)

